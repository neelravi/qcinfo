[![Upload Python Package](https://github.com/neelravi/qcinfo/actions/workflows/python-publish.yml/badge.svg)](https://github.com/neelravi/qcinfo/actions/workflows/python-publish.yml)
